/**
 * Matrix360 Real Estate Lead Platform - Engage Team Component Server
 * 
 * Maintainer: Tanmayi (Engage Team)
 * Integrations:
 * - Mayur: Shared ReferralOps Database & Grok AI proxy
 * - Avinash: Shared Hot/Warm/Cold classification (WhatsApp & Website Chat)
 * - Peeyusha & Pratha: Central policy gate for outbound signals
 * - Shalini: Shree Heights RERA facts & campaign compliance
 */

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

import { sharedDbClient } from './lib/sharedDbClient.js';
import { evaluateMessagePolicy } from './lib/policyGate.js';
import { engageWorkflow } from './lib/engageWorkflow.js';
import { whatsappClient } from './lib/whatsappClient.js';
import { auditLogger } from './lib/auditLogger.js';
import { classifyCustomerIntent } from './lib/intentClassifier.js';
import { VERIFIED_PROJECTS } from './lib/campaignKnowledge.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// -------------------------------------------------------------
// 1. Health & Integration Status Endpoint
// -------------------------------------------------------------
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    component: 'Matrix360 Engage Team',
    lead_database: {
      mode: sharedDbClient.getMode(),
      target_url: process.env.SHARED_DB_URL || 'http://localhost:4000',
      connected: sharedDbClient.useDevAdapter ? 'dev_adapter_active' : 'live_db_connected'
    },
    grok_ai: {
      mode: process.env.USE_MOCK_GROK === 'false' ? 'live_proxy' : 'deterministic_interpreter',
      target_url: process.env.GROK_PROXY_URL
    },
    whatsapp: {
      configured: whatsappClient.isConfigured(),
      mock_mode: process.env.WHATSAPP_MOCK_SEND === 'true',
      phone_id: process.env.WHATSAPP_PHONE_NUMBER_ID ? '[CONFIGURED]' : '[MISSING_CREDENTIALS]'
    }
  });
});

// -------------------------------------------------------------
// 2. Lead Management Endpoints (Reusing Mayur's Shared DB)
// -------------------------------------------------------------
app.get('/api/leads', async (req, res) => {
  try {
    const leads = await sharedDbClient.getLeads(req.query);
    res.json({
      success: true,
      mode: sharedDbClient.getMode(),
      count: leads.length,
      leads
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/leads/:id', async (req, res) => {
  try {
    const lead = await sharedDbClient.getLeadById(req.params.id);
    if (!lead) return res.status(404).json({ success: false, error: 'Lead not found' });
    res.json({ success: true, lead });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// -------------------------------------------------------------
// 3. Central Policy Gate Evaluation Endpoint
// Used by all team members (including Peeyusha) before sending!
// -------------------------------------------------------------
app.post('/api/policy/check', async (req, res) => {
  try {
    const { lead_id, lead: rawLead, message, context } = req.body;
    let lead = rawLead;
    if (!lead && lead_id) {
      lead = await sharedDbClient.getLeadById(lead_id);
    }

    if (!lead) {
      return res.status(400).json({
        allowed: false,
        reason_code: 'MISSING_LEAD',
        reason_detail: 'Lead record or valid lead_id is required for policy check.'
      });
    }

    const contactHistory = await sharedDbClient.getContactHistory(lead.lead_id);
    const result = evaluateMessagePolicy({
      lead,
      message,
      context: {
        ...(context || {}),
        contact_history: contactHistory
      }
    });

    res.json(result);
  } catch (err) {
    res.status(500).json({ allowed: false, error: err.message });
  }
});

// -------------------------------------------------------------
// 4. Outbound Outreach Trigger & Approval Queue
// -------------------------------------------------------------
app.post('/api/outbound/trigger', async (req, res) => {
  try {
    const { lead_id, message_type, custom_text, template_name, auto_approve } = req.body;
    if (!lead_id) {
      return res.status(400).json({ success: false, error: 'lead_id is required' });
    }

    const result = await engageWorkflow.processOutbound({
      leadId: lead_id,
      messageType: message_type || 'first_outreach',
      customText: custom_text,
      templateName: template_name,
      autoApprove: Boolean(auto_approve)
    });

    res.json({ success: true, result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/approvals/pending', (req, res) => {
  const jobs = Array.from(engageWorkflow.pendingApprovals.values());
  res.json({ success: true, count: jobs.length, jobs });
});

app.post('/api/approvals/:jobId/approve', async (req, res) => {
  try {
    const result = await engageWorkflow.approvePendingOutreach(req.params.jobId, req.body.operator || 'Tanmayi');
    res.json({ success: true, result });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

app.post('/api/approvals/:jobId/reject', async (req, res) => {
  try {
    const result = await engageWorkflow.rejectPendingOutreach(req.params.jobId, req.body.reason, req.body.operator || 'Tanmayi');
    res.json({ success: true, result });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// -------------------------------------------------------------
// 5. WhatsApp Webhook (Meta Verified Protocol & Inbound Handler)
// -------------------------------------------------------------
// Meta Webhook Verification Challenge
app.get('/api/webhook/whatsapp', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  const verified = whatsappClient.verifyWebhook(mode, token, challenge);
  if (verified) {
    console.log('[Webhook] Meta WhatsApp webhook successfully verified.');
    return res.status(200).send(challenge);
  }
  return res.status(403).send('Verification token mismatch');
});

// Meta Webhook Inbound Message Event
app.post('/api/webhook/whatsapp', async (req, res) => {
  try {
    const body = req.body;

    // Check signature if secret configured
    const sigHeader = req.headers['x-hub-signature-256'];
    if (sigHeader && !whatsappClient.verifySignature(JSON.stringify(body), sigHeader)) {
      console.warn('[Webhook] Invalid X-Hub-Signature-256 header.');
      return res.status(401).send('Signature verification failed');
    }

    // Acknowledge Meta immediately to avoid retries
    res.status(200).json({ status: 'EVENT_RECEIVED' });

    // Handle Meta WhatsApp format or simplified test webhook format
    let messageId, phone, text, leadId;

    if (body.object === 'whatsapp_business_account') {
      const entry = body.entry?.[0];
      const change = entry?.changes?.[0]?.value;
      const message = change?.messages?.[0];

      if (!message) return; // status update or non-message event

      messageId = message.id;
      phone = message.from;
      text = message.text?.body || message.button?.text || '';
    } else {
      // Simplified test format
      messageId = body.message_id || `sim_${Date.now()}`;
      phone = body.phone;
      text = body.text || '';
      leadId = body.lead_id;
    }

    // Process through the 12-step inbound workflow
    await engageWorkflow.processInboundWebhook({
      messageId,
      leadId,
      phone,
      text,
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    console.error('[Webhook] Inbound error:', err);
  }
});

// -------------------------------------------------------------
// 6. Coordination Endpoint with Avinash (Website Chat)
// -------------------------------------------------------------
app.post('/api/classify', (req, res) => {
  const { text, previous_context, channel } = req.body;
  const classification = classifyCustomerIntent({
    text,
    previousContext: previous_context,
    channel: channel || 'website_chat'
  });
  res.json({ success: true, classification });
});

// -------------------------------------------------------------
// 7. Audit Log Viewer & Campaign Facts
// -------------------------------------------------------------
app.get('/api/audit', (req, res) => {
  const entries = auditLogger.getEntries(req.query);
  res.json({ success: true, count: entries.length, entries });
});

app.get('/api/projects', (req, res) => {
  res.json({ success: true, projects: VERIFIED_PROJECTS });
});

// Start Server
app.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`Matrix360 Engage Team Service running on port ${PORT}`);
  console.log(`Mode: ${sharedDbClient.getMode()}`);
  console.log(`Grok: ${process.env.USE_MOCK_GROK === 'false' ? 'Live Proxy' : 'Deterministic Mode'}`);
  console.log(`Policy Gate: Active (Max ${process.env.MAX_CONTACTS_PER_WEEK || 2} contacts / 7d)`);
  console.log(`RERA Verified: WBRERA/P/HOO/2023/000504 (Shree Heights)`);
  console.log(`Dashboard: http://localhost:${PORT}`);
  console.log(`====================================================`);
});
