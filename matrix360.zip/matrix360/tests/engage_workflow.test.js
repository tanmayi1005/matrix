/**
 * Matrix360 Engage Team Test Suite
 * 
 * Verifies all 12 test cases specified in Step 9:
 * 1. A lead with valid consent passing the gate.
 * 2. A lead with missing consent being blocked.
 * 3. A lead who has opted out being blocked.
 * 4. A lead exceeding the contact cap being blocked.
 * 5. A message outside the permitted sending window being blocked.
 * 6. STOP cancelling pending outreach.
 * 7. A customer asking about pricing without verified pricing being invented.
 * 8. A customer saying yes after being offered a callback or site visit.
 * 9. A site-visit request producing the correct next-action recommendation.
 * 10. Grok returning malformed JSON or becoming unavailable.
 * 11. Repeated webhooks not causing duplicate actions.
 * 12. The WhatsApp and website-chat channels applying the same hot/warm/cold rules.
 */

import { test, describe, beforeEach } from 'node:test';
import assert from 'node:assert/strict';

import { evaluateMessagePolicy } from '../lib/policyGate.js';
import { devDbAdapter } from '../lib/devDbAdapter.js';
import { sharedDbClient } from '../lib/sharedDbClient.js';
import { grokClient } from '../lib/grokClient.js';
import { engageWorkflow } from '../lib/engageWorkflow.js';
import { classifyCustomerIntent, INTENT_LEVELS } from '../lib/intentClassifier.js';
import { idempotencyManager } from '../lib/idempotency.js';
import { validateFactsInText } from '../lib/campaignKnowledge.js';

describe('Matrix360 Engage Team Workflow & Policy Gate Suite', () => {
  beforeEach(() => {
    devDbAdapter.reset();
    idempotencyManager.clear();
    engageWorkflow.pendingApprovals.clear();
    engageWorkflow.conversationHistory.clear();
  });

  // -------------------------------------------------------------
  // Test Case 1: Lead with valid consent passing the gate
  // -------------------------------------------------------------
  test('1. A lead with valid consent passing the gate', () => {
    const lead = {
      lead_id: 'lead_test_01',
      client: 'Shree Heights',
      name: 'Rohan Sharma',
      phone: '+919830099991',
      consent: true,
      opted_out: false
    };

    const message = {
      text: 'Hello Rohan, welcome to Shree Heights.',
      is_template: true,
      template_name: 'shree_heights_first_outreach'
    };

    // Daytime IST (14:00)
    const daytime = new Date('2026-10-12T08:30:00Z'); // 14:00 IST

    const result = evaluateMessagePolicy({
      lead,
      message,
      context: { now: daytime, contact_history: [] }
    });

    assert.equal(result.allowed, true);
    assert.equal(result.reason_code, 'POLICY_PASSED');
    assert.equal(result.checks.consent_valid, true);
    assert.equal(result.checks.opt_out_cleared, true);
  });

  // -------------------------------------------------------------
  // Test Case 2: Lead with missing consent being blocked
  // -------------------------------------------------------------
  test('2. A lead with missing consent being blocked', () => {
    const leadNoConsent = {
      lead_id: 'lead_test_02',
      client: 'Shree Heights',
      name: 'Ananya Roy',
      phone: '+919830099992',
      consent: false, // NO CONSENT
      opted_out: false
    };

    const daytime = new Date('2026-10-12T08:30:00Z');
    const result = evaluateMessagePolicy({
      lead: leadNoConsent,
      message: { text: 'Hello', is_template: true, template_name: 'shree_heights_first_outreach' },
      context: { now: daytime, contact_history: [] }
    });

    assert.equal(result.allowed, false);
    assert.equal(result.reason_code, 'CONSENT_MISSING');
    assert.equal(result.checks.consent_valid, false);
  });

  // -------------------------------------------------------------
  // Test Case 3: Lead who has opted out being blocked
  // -------------------------------------------------------------
  test('3. A lead who has opted out being blocked', () => {
    const leadOptedOut = {
      lead_id: 'lead_test_03',
      client: 'Shree Heights',
      name: 'Karan Mehra',
      phone: '+919830099993',
      consent: true,
      opted_out: true // OPTED OUT
    };

    const daytime = new Date('2026-10-12T08:30:00Z');
    const result = evaluateMessagePolicy({
      lead: leadOptedOut,
      message: { text: 'Hello', is_template: true, template_name: 'shree_heights_first_outreach' },
      context: { now: daytime, contact_history: [] }
    });

    assert.equal(result.allowed, false);
    assert.equal(result.reason_code, 'LEAD_OPTED_OUT');
    assert.equal(result.checks.opt_out_cleared, false);
  });

  // -------------------------------------------------------------
  // Test Case 4: Lead exceeding the contact cap being blocked
  // -------------------------------------------------------------
  test('4. A lead exceeding the contact cap being blocked (max 2 in 7 days)', () => {
    const lead = {
      lead_id: 'lead_test_04',
      client: 'Shree Heights',
      name: 'Sunita Paul',
      phone: '+919830099994',
      consent: true,
      opted_out: false
    };

    const daytime = new Date('2026-10-12T08:30:00Z');
    // Already contacted 2 times in the last 4 days
    const contactHistory = [
      { timestamp: new Date('2026-10-10T08:30:00Z').toISOString(), direction: 'outbound', status: 'sent' },
      { timestamp: new Date('2026-10-11T08:30:00Z').toISOString(), direction: 'outbound', status: 'sent' }
    ];

    const result = evaluateMessagePolicy({
      lead,
      message: { text: 'Hello', is_template: true, template_name: 'shree_heights_first_outreach' },
      context: { now: daytime, contact_history: contactHistory }
    });

    assert.equal(result.allowed, false);
    assert.equal(result.reason_code, 'CONTACT_FREQUENCY_EXCEEDED');
    assert.equal(result.checks.frequency_cleared, false);
  });

  // -------------------------------------------------------------
  // Test Case 5: Message outside permitted sending window being blocked
  // -------------------------------------------------------------
  test('5. A message outside the permitted sending window being blocked (e.g. 23:30 IST)', () => {
    const lead = {
      lead_id: 'lead_test_05',
      client: 'Shree Heights',
      name: 'Vikram Das',
      phone: '+919830099995',
      consent: true,
      opted_out: false
    };

    // 23:30 IST is 18:00 UTC
    const lateNight = new Date('2026-10-12T18:00:00Z');

    const result = evaluateMessagePolicy({
      lead,
      message: { text: 'Hello', is_template: true, template_name: 'shree_heights_first_outreach' },
      context: { now: lateNight, contact_history: [] }
    });

    assert.equal(result.allowed, false);
    assert.equal(result.reason_code, 'OUTSIDE_SENDING_WINDOW');
    assert.equal(result.checks.window_cleared, false);
  });

  // -------------------------------------------------------------
  // Test Case 6: STOP cancelling pending outreach
  // -------------------------------------------------------------
  test('6. STOP cancelling pending outreach and updating opt-out persistently', async () => {
    const leadId = 'lead_sotefin_001';
    const daytime = new Date('2026-10-12T08:30:00Z');

    // 1. Queue an outbound message (requires human approval)
    const outboundResult = await engageWorkflow.processOutbound({
      leadId,
      messageType: 'first_outreach',
      now: daytime
    });
    assert.equal(outboundResult.status, 'PENDING_APPROVAL');
    assert.equal(engageWorkflow.pendingApprovals.size, 1);

    // 2. Inbound webhook arrives with "STOP"
    const inboundResult = await engageWorkflow.processInboundWebhook({
      messageId: 'wamid_stop_123',
      leadId,
      text: 'STOP'
    });

    assert.equal(inboundResult.status, 'OPTED_OUT');

    // 3. Pending outreach is cancelled
    assert.equal(engageWorkflow.pendingApprovals.size, 0);

    // 4. Lead is persistently opted out in database
    const updatedLead = await sharedDbClient.getLeadById(leadId);
    assert.equal(updatedLead.opted_out, true);
    assert.equal(updatedLead.stage, 'opted_out');
    assert.equal(updatedLead.intent, 'cold');

    // 5. Any subsequent outbound attempts are blocked
    const subsequentAttempt = await engageWorkflow.processOutbound({
      leadId,
      now: daytime
    });
    assert.equal(subsequentAttempt.status, 'BLOCKED');
    assert.equal(subsequentAttempt.reason_code, 'LEAD_OPTED_OUT');
  });

  // -------------------------------------------------------------
  // Test Case 7: Customer asking about pricing without verified pricing being invented
  // -------------------------------------------------------------
  test('7. A customer asking about pricing without verified pricing being invented', async () => {
    const lead = await sharedDbClient.getLeadById('lead_shree_002');
    const customerMsg = 'What is the exact price of the 3 BHK flat? Can you give me the total cost?';

    const interpretation = await grokClient.interpretReply({
      lead,
      customerMessage: customerMsg,
      conversationHistory: []
    });

    assert.equal(interpretation.intent, 'warm');
    assert.ok(interpretation.proposed_reply.includes('₹70 lakhs onwards'));
    // Ensures no unverified specific price was fabricated
    const factCheck = validateFactsInText(interpretation.proposed_reply, 'Shree Heights');
    assert.equal(factCheck.valid, true);

    // Also verify fact check validator catches illegal unverified prices
    const fakePriceText = 'The 3 BHK is available for ₹85.5 lakhs today only!';
    const fakeCheck = validateFactsInText(fakePriceText, 'Shree Heights');
    assert.equal(fakeCheck.valid, false);
    assert.ok(fakeCheck.violation.includes('Unverified price claim'));
  });

  // -------------------------------------------------------------
  // Test Case 8: Customer saying yes after being offered a callback or site visit
  // -------------------------------------------------------------
  test('8. A customer saying yes after being offered a callback or site visit', async () => {
    const lead = await sharedDbClient.getLeadById('lead_shree_002');
    const thread = [
      {
        direction: 'outbound',
        text: 'Would you like to schedule a private site visit this week at Shree Heights?'
      }
    ];

    const interpretation = await grokClient.interpretReply({
      lead,
      customerMessage: 'Yes, sure that would be great',
      conversationHistory: thread
    });

    assert.equal(interpretation.intent, 'hot');
    assert.equal(interpretation.proposed_next_action, 'schedule_site_visit');
    assert.ok(interpretation.proposed_reply.toLowerCase().includes('visit'));
  });

  // -------------------------------------------------------------
  // Test Case 9: Site-visit request producing correct next-action recommendation
  // -------------------------------------------------------------
  test('9. A site-visit request producing the correct next-action recommendation', async () => {
    const leadId = 'lead_shree_002';
    const inbound = await engageWorkflow.processInboundWebhook({
      messageId: 'wamid_visit_request_456',
      leadId,
      text: 'I would like to come for a site visit this Saturday with my family'
    });

    assert.equal(inbound.status, 'PROCESSED');
    assert.equal(inbound.intent, 'hot');
    assert.equal(inbound.proposed_next_action, 'schedule_site_visit');

    const updatedLead = await sharedDbClient.getLeadById(leadId);
    assert.equal(updatedLead.intent, 'hot');
    assert.equal(updatedLead.stage, 'visit_booked');
    assert.equal(updatedLead.next_action, 'schedule_site_visit');
  });

  // -------------------------------------------------------------
  // Test Case 10: Grok returning malformed JSON or becoming unavailable
  // -------------------------------------------------------------
  test('10. Grok returning malformed JSON or becoming unavailable falls back safely', () => {
    const lead = { client: 'Shree Heights', lead_id: 'test_lead_err' };
    const malformedOutput = 'This is raw text without valid JSON markup: { broken json...';

    // Verify parser handles error without crashing
    assert.throws(() => {
      grokClient.parseAndValidateResponse(malformedOutput, lead);
    }, /Malformed JSON/);

    // Verify deterministic fallback provides complete schema
    const fallback = grokClient.deterministicFallbackInterpret({
      lead,
      customerMessage: 'Can you tell me about the project?',
      failureReason: 'Grok service timeout'
    });

    assert.ok(fallback.intent);
    assert.ok(fallback.proposed_reply);
    assert.ok(fallback.proposed_next_action);
    assert.equal(fallback._fallback_used, true);
    assert.ok(typeof fallback.confidence === 'number');
  });

  // -------------------------------------------------------------
  // Test Case 11: Repeated webhooks not causing duplicate actions
  // -------------------------------------------------------------
  test('11. Repeated webhooks not causing duplicate actions (Idempotency)', async () => {
    const messageId = 'wamid_duplicate_test_789';
    const leadId = 'lead_shree_002';

    // First processing
    const firstRun = await engageWorkflow.processInboundWebhook({
      messageId,
      leadId,
      text: 'What are the amenities?'
    });
    assert.equal(firstRun.status, 'PROCESSED');

    // Duplicate webhook with same messageId
    const secondRun = await engageWorkflow.processInboundWebhook({
      messageId,
      leadId,
      text: 'What are the amenities?'
    });
    assert.equal(secondRun.status, 'DUPLICATE_DROPPED');
    assert.equal(secondRun.message_id, messageId);
  });

  // -------------------------------------------------------------
  // Test Case 12: WhatsApp and website-chat channels applying the same hot/warm/cold rules
  // -------------------------------------------------------------
  test('12. The WhatsApp and website-chat channels applying the same hot/warm/cold rules', () => {
    const testCases = [
      { text: 'I want to book a site visit for Shree Heights', expectedIntent: 'hot' },
      { text: 'Can someone call me back at 5 PM?', expectedIntent: 'hot' },
      { text: 'What is the price of 2 BHK?', expectedIntent: 'warm' },
      { text: 'Send me the brochure', expectedIntent: 'warm' },
      { text: 'Not interested at all', expectedIntent: 'cold' },
      { text: 'STOP', expectedIntent: 'cold' }
    ];

    for (const tc of testCases) {
      const waResult = classifyCustomerIntent({ text: tc.text, channel: 'whatsapp' });
      const webResult = classifyCustomerIntent({ text: tc.text, channel: 'website_chat' });

      assert.equal(waResult.intent, tc.expectedIntent, `WhatsApp channel classification failed for "${tc.text}"`);
      assert.equal(webResult.intent, tc.expectedIntent, `Website chat channel classification failed for "${tc.text}"`);
      assert.equal(waResult.intent, webResult.intent, `Mismatch between channels for "${tc.text}"`);
    }
  });

  // -------------------------------------------------------------
  // Test Case 13: Shree Heights Emailer Pre-filled Inbound Recognition
  // -------------------------------------------------------------
  test('13. Recognizing Shree Heights emailer pre-filled WhatsApp message as HOT site-visit request', async () => {
    const lead = await sharedDbClient.getLeadById('lead_shree_002');
    const emailerInbound = 'Hello, I received your email about Shree Heights. I would like to know more and arrange a site visit.';

    const interpretation = await grokClient.interpretReply({
      lead,
      customerMessage: emailerInbound,
      conversationHistory: []
    });

    assert.equal(interpretation.intent, 'hot');
    assert.equal(interpretation.proposed_next_action, 'schedule_site_visit');
    assert.ok(interpretation.proposed_reply.toLowerCase().includes('site visit') || interpretation.proposed_reply.toLowerCase().includes('visit'));
    // Ensures no broken placeholder is output
    assert.equal(interpretation.proposed_reply.includes('{{CALENDLY'), false);
  });

  // -------------------------------------------------------------
  // Test Case 14: Vrindavan Greens Emailer Pre-filled Inbound & Placeholder Safeguard
  // -------------------------------------------------------------
  test('14. Vrindavan Greens emailer pre-filled message recognized as HOT and NEVER uses {{CALENDLY_URL}}', async () => {
    const lead = {
      lead_id: 'lead_vrindavan_test',
      client: 'Vrindavan Greens',
      property_type: 'plots'
    };
    const emailerInbound = 'Hello, I received your email about Vrindavan Greens, Madanpur. I would like to know more and arrange a site visit.';

    const interpretation = await grokClient.interpretReply({
      lead,
      customerMessage: emailerInbound,
      conversationHistory: []
    });

    assert.equal(interpretation.intent, 'hot');
    assert.equal(interpretation.proposed_next_action, 'schedule_site_visit');
    // Critical safeguard: {{CALENDLY_URL}} is NEVER output
    assert.equal(interpretation.proposed_reply.includes('{{CALENDLY_URL}}'), false);
    assert.equal(interpretation.proposed_reply.includes('{{'), false);
    // Asks for preferred date and time slot
    assert.ok(interpretation.proposed_reply.toLowerCase().includes('date and time'));
    assert.ok(interpretation.proposed_reply.toLowerCase().includes('madanpur'));
  });

  // -------------------------------------------------------------
  // Test Case 15: Vrindavan Greens Location & Amenities from Campaign Source
  // -------------------------------------------------------------
  test('15. Vrindavan Greens location (Madanpur) and amenities (mandir, club house) answered accurately', async () => {
    const lead = {
      lead_id: 'lead_vrindavan_test2',
      client: 'Vrindavan Greens',
      property_type: 'plots'
    };

    // Location query
    const locReply = await grokClient.interpretReply({
      lead,
      customerMessage: 'Where is Vrindavan Greens located?',
      conversationHistory: []
    });
    assert.equal(locReply.intent, 'warm');
    assert.ok(locReply.proposed_reply.toLowerCase().includes('madanpur'));
    assert.ok(locReply.proposed_reply.toLowerCase().includes('kalyani'));

    // Amenities query
    const amenReply = await grokClient.interpretReply({
      lead,
      customerMessage: 'What amenities are planned at Vrindavan Greens?',
      conversationHistory: []
    });
    assert.equal(amenReply.intent, 'warm');
    assert.ok(amenReply.proposed_reply.toLowerCase().includes('mandir'));
    assert.ok(amenReply.proposed_reply.toLowerCase().includes('club house') || amenReply.proposed_reply.toLowerCase().includes('swimming pool'));
  });

  // -------------------------------------------------------------
  // Test Case 16: Vrindavan Greens Pricing Claim Handled with Clarification Note
  // -------------------------------------------------------------
  test('16. Vrindavan Greens pricing question acknowledges campaign promotional mention without fabricating verified price', async () => {
    const lead = {
      lead_id: 'lead_vrindavan_test3',
      client: 'Vrindavan Greens',
      property_type: 'plots'
    };

    const priceReply = await grokClient.interpretReply({
      lead,
      customerMessage: 'How much do the homes cost at Vrindavan Greens? Is it 50 Lakhs?',
      conversationHistory: []
    });

    assert.equal(priceReply.intent, 'warm');
    assert.ok(priceReply.proposed_reply.includes('₹50 Lakhs onwards'));
    // Guardrail: must note that exact pricing depends on plot size / bungalow design and requires sales confirmation
    assert.ok(priceReply.proposed_reply.toLowerCase().includes('sales') || priceReply.proposed_reply.toLowerCase().includes('custom'));
    
    // Fact validator check
    const factCheck = validateFactsInText(priceReply.proposed_reply, 'Vrindavan Greens');
    assert.equal(factCheck.valid, true);

    // Assert that unsupported claim without disclaimer is blocked
    const illegalClaim = 'The final verified price for a 3-bedroom villa is ₹50 Lakhs all inclusive!';
    const illegalCheck = validateFactsInText(illegalClaim, 'Vrindavan Greens');
    assert.equal(illegalCheck.valid, false);
  });

  // -------------------------------------------------------------
  // Test Case 17: Inbound campaign reply does NOT bypass policy safeguards on subsequent sends
  // -------------------------------------------------------------
  test('17. Inbound campaign reply does not bypass mandatory policy safeguards (opt-out, frequency)', async () => {
    const leadOptedOut = {
      lead_id: 'lead_opted_out_campaign',
      client: 'Vrindavan Greens',
      phone: '+919830099990',
      consent: true,
      opted_out: true // Lead has opted out
    };

    // Even if an inbound was simulated, subsequent outbound is blocked by policy gate
    const policyResult = evaluateMessagePolicy({
      lead: leadOptedOut,
      message: { text: 'Hello', is_template: true, template_name: 'vrindavan_greens_outreach' },
      context: { now: new Date('2026-10-12T08:30:00Z') }
    });

    assert.equal(policyResult.allowed, false);
    assert.equal(policyResult.reason_code, 'LEAD_OPTED_OUT');
  });
});
