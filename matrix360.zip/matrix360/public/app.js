/**
 * Matrix360 Engage Team Dashboard - Client Application
 * Powers Tanmayi's Operator Console
 */

let allLeads = [];
let activeSimulatorLeadId = 'lead_shree_002';

document.addEventListener('DOMContentLoaded', () => {
  initClock();
  initTabs();
  fetchHealth();
  fetchLeads();
  fetchPendingApprovals();
  fetchAuditLogs();
  initSimulator();
  initPolicyGateInspector();

  // Polling for live updates every 5 seconds
  setInterval(() => {
    fetchPendingApprovals();
    fetchHealth();
  }, 5000);
});

// -------------------------------------------------------------
// Live Clock (Asia/Kolkata)
// -------------------------------------------------------------
function initClock() {
  const clockEl = document.getElementById('clock-display');
  function update() {
    try {
      const now = new Date();
      const timeStr = new Intl.DateTimeFormat('en-IN', {
        timeZone: 'Asia/Kolkata',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      }).format(now);
      clockEl.textContent = `${timeStr} IST`;
    } catch {
      clockEl.textContent = new Date().toLocaleTimeString();
    }
  }
  update();
  setInterval(update, 1000);
}

// -------------------------------------------------------------
// Tabs Switching
// -------------------------------------------------------------
function initTabs() {
  const buttons = document.querySelectorAll('.tab-btn');
  const panes = document.querySelectorAll('.tab-pane');

  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');
      buttons.forEach(b => b.classList.remove('active'));
      panes.forEach(p => p.classList.remove('active'));

      btn.classList.add('active');
      const activePane = document.getElementById(targetTab);
      if (activePane) activePane.classList.add('active');

      if (targetTab === 'tab-leads') fetchLeads();
      if (targetTab === 'tab-audit') fetchAuditLogs();
    });
  });
}

// -------------------------------------------------------------
// Fetch Health & Config
// -------------------------------------------------------------
async function fetchHealth() {
  try {
    const res = await fetch('/api/health');
    const data = await res.json();

    const dbPill = document.getElementById('pill-db');
    if (data.lead_database.mode.includes('mock') || data.lead_database.mode.includes('adapter')) {
      dbPill.querySelector('.text').textContent = 'DB: Dev Adapter';
    } else {
      dbPill.querySelector('.text').textContent = 'DB: Live Shared DB';
    }

    const grokPill = document.getElementById('pill-grok');
    if (data.grok_ai.mode === 'live_proxy') {
      grokPill.querySelector('.text').textContent = 'Grok: Live Proxy';
    } else {
      grokPill.querySelector('.text').textContent = 'Grok: Deterministic AI';
    }
  } catch (err) {
    console.warn('Failed to load health status', err);
  }
}

// -------------------------------------------------------------
// Shared Leads Management
// -------------------------------------------------------------
async function fetchLeads() {
  try {
    const clientFilter = document.getElementById('filter-client').value;
    const url = clientFilter ? `/api/leads?client=${encodeURIComponent(clientFilter)}` : '/api/leads';
    const res = await fetch(url);
    const data = await res.json();
    allLeads = data.leads || [];

    renderLeadsTable(allLeads);
    updateStats(allLeads);
  } catch (err) {
    console.error('Failed to load leads', err);
  }
}

document.getElementById('filter-client').addEventListener('change', fetchLeads);
document.getElementById('btn-refresh-leads').addEventListener('click', fetchLeads);

function updateStats(leads) {
  document.getElementById('stat-total-leads').textContent = leads.length;
  const hotLeads = leads.filter(l => l.intent === 'hot');
  document.getElementById('stat-hot-leads').textContent = hotLeads.length;
}

function renderLeadsTable(leads) {
  const tbody = document.getElementById('leads-table-body');
  tbody.innerHTML = '';

  if (leads.length === 0) {
    tbody.innerHTML = '<tr><td colspan="10" class="loading-td">No leads found in database.</td></tr>';
    return;
  }

  leads.forEach(lead => {
    const tr = document.createElement('tr');

    const consentBadge = (lead.consent === true || lead.consent === 'true')
      ? '<span class="badge-pill yes">VERIFIED</span>'
      : '<span class="badge-pill no">MISSING</span>';

    const optOutBadge = lead.opted_out
      ? '<span class="badge-pill no">OPTED OUT</span>'
      : '<span class="badge-pill yes">ACTIVE</span>';

    const intentClass = lead.intent === 'hot' ? 'hot' : (lead.intent === 'warm' ? 'warm' : 'cold');
    const intentBadge = `<span class="badge-pill ${intentClass}">${(lead.intent || 'WARM').toUpperCase()}</span>`;

    const mockTag = lead._is_mock_data ? '<br><span class="mock-badge">dev_adapter</span>' : '';

    tr.innerHTML = `
      <td>
        <strong>${escapeHtml(lead.name || 'Unnamed')}</strong>${mockTag}
        <div style="font-size:0.75rem; color:var(--text-dim);">${escapeHtml(lead.lead_id)}</div>
      </td>
      <td>
        <strong>${escapeHtml(lead.client || '-')}</strong>
        <div style="font-size:0.75rem; color:var(--text-dim);">${escapeHtml(lead.property_type || '-')} (${escapeHtml(lead.lead_type || '-')})</div>
      </td>
      <td>
        <span style="font-size:0.8rem; font-weight:600;">${escapeHtml(lead.source || '-')}</span>
        <div style="font-size:0.72rem; color:var(--text-dim); max-width:140px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${escapeHtml(lead.evidence || '')}">${escapeHtml(lead.evidence || '-')}</div>
      </td>
      <td>${consentBadge}</td>
      <td>${optOutBadge}</td>
      <td>
        <strong>${lead.fit_score || 0}</strong>/100
        <div style="font-size:0.7rem; color:var(--text-dim); max-width:120px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${escapeHtml(lead.fit_reasons || '')}">${escapeHtml(lead.fit_reasons || '-')}</div>
      </td>
      <td>${intentBadge}</td>
      <td><span style="font-size:0.8rem; font-weight:600; text-transform:capitalize;">${escapeHtml(lead.stage || '-')}</span></td>
      <td><code style="font-size:0.75rem; color:#fde047;">${escapeHtml(lead.next_action || '-')}</code></td>
      <td>
        <button class="btn btn-secondary btn-sm" onclick="triggerOutreachForLead('${lead.lead_id}')" style="padding:0.3rem 0.6rem; font-size:0.75rem;">
          📤 Trigger Outreach
        </button>
      </td>
    `;

    tbody.appendChild(tr);
  });
}

// -------------------------------------------------------------
// Human Approvals Queue
// -------------------------------------------------------------
async function fetchPendingApprovals() {
  try {
    const res = await fetch('/api/approvals/pending');
    const data = await res.json();
    const jobs = data.jobs || [];

    const badge = document.getElementById('approval-badge');
    const statPending = document.getElementById('stat-pending-approvals');
    const section = document.getElementById('approval-section');
    const queueList = document.getElementById('approval-queue-list');

    statPending.textContent = jobs.length;

    if (jobs.length > 0) {
      badge.textContent = jobs.length;
      badge.style.display = 'inline-block';
      section.style.display = 'block';
    } else {
      badge.style.display = 'none';
      section.style.display = 'none';
      queueList.innerHTML = '';
      return;
    }

    queueList.innerHTML = '';
    jobs.forEach(job => {
      const card = document.createElement('div');
      card.className = 'approval-card';
      card.innerHTML = `
        <div class="approval-card-head">
          <div>
            <strong>${escapeHtml(job.lead.name || 'Lead')}</strong> (${escapeHtml(job.lead.client || 'Shree Heights')})
            <div style="font-size:0.75rem; color:var(--text-dim);">${escapeHtml(job.lead_id)} · ${escapeHtml(job.lead.phone || '')}</div>
          </div>
          <span class="badge-pill warm">HUMAN APPROVAL REQUIRED</span>
        </div>
        <div class="approval-msg-box">
          "${escapeHtml(job.messagePayload.text || '')}"
        </div>
        <div style="font-size:0.75rem; color:var(--text-dim);">
          Template: <code>${escapeHtml(job.messagePayload.template_name || 'custom')}</code> | Policy Gate: <span style="color:#34d399;">PASSED</span>
        </div>
        <div class="approval-actions">
          <button class="btn btn-primary" onclick="approveJob('${job.job_id}')">Approve & Send</button>
          <button class="btn btn-secondary" onclick="rejectJob('${job.job_id}')">Reject</button>
        </div>
      `;
      queueList.appendChild(card);
    });
  } catch (err) {
    console.warn('Failed to load pending approvals', err);
  }
}

window.approveJob = async function(jobId) {
  try {
    const res = await fetch(`/api/approvals/${jobId}/approve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ operator: 'Tanmayi' })
    });
    const data = await res.json();
    if (data.success) {
      alert('Outbound message approved and safely dispatched!');
      fetchPendingApprovals();
      fetchLeads();
      fetchAuditLogs();
    } else {
      alert(`Approval error: ${data.error}`);
    }
  } catch (err) {
    alert(`Request error: ${err.message}`);
  }
};

window.rejectJob = async function(jobId) {
  try {
    const reason = prompt('Please enter rejection reason:', 'Operator cancelled outreach');
    if (!reason) return;
    const res = await fetch(`/api/approvals/${jobId}/reject`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason, operator: 'Tanmayi' })
    });
    fetchPendingApprovals();
    fetchAuditLogs();
  } catch (err) {
    alert(`Request error: ${err.message}`);
  }
};

window.triggerOutreachForLead = async function(leadId) {
  try {
    const res = await fetch('/api/outbound/trigger', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ lead_id: leadId, message_type: 'first_outreach' })
    });
    const data = await res.json();
    if (data.result?.status === 'BLOCKED') {
      alert(`Policy Gate Blocked Outbound Message:\nReason: ${data.result.reason_code}\n${data.result.reason_detail}`);
    } else if (data.result?.status === 'PENDING_APPROVAL') {
      alert(`Message cleared Policy Gate!\nQueued for Human Approval per Step 5 safety rule.`);
    } else {
      alert(`Message Status: ${data.result?.status}`);
    }
    fetchPendingApprovals();
    fetchLeads();
    fetchAuditLogs();
  } catch (err) {
    alert(`Trigger error: ${err.message}`);
  }
};

// -------------------------------------------------------------
// WhatsApp Simulator & Webhook
// -------------------------------------------------------------
function initSimulator() {
  const form = document.getElementById('sim-input-form');
  const input = document.getElementById('sim-text-input');
  const chipButtons = document.querySelectorAll('.chip-btn');

  chipButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const msg = btn.getAttribute('data-msg');
      input.value = msg;
      form.dispatchEvent(new Event('submit'));
    });
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    input.value = '';

    appendChatMessage(text, 'inbound');

    try {
      const res = await fetch('/api/webhook/whatsapp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lead_id: activeSimulatorLeadId,
          text: text,
          message_id: `sim_wamid_${Date.now()}`
        })
      });

      // Fetch updated lead record to see intent and proposed reply
      setTimeout(async () => {
        const leadRes = await fetch(`/api/leads/${activeSimulatorLeadId}`);
        const leadData = await leadRes.json();
        const updatedLead = leadData.lead;

        if (updatedLead) {
          updateGrokInspector(updatedLead, text);

          // If opt out
          if (updatedLead.opted_out) {
            appendChatMessage('🚫 Lead opted out (STOP). Outbound communication halted permanently.', 'outbound');
          } else {
            // Find latest proposed reply from audit log
            const auditRes = await fetch(`/api/audit?lead_id=${activeSimulatorLeadId}`);
            const auditData = await auditRes.json();
            const latestAudit = auditData.entries?.[0];
            const proposedReply = latestAudit?.details?.proposed_reply;

            if (proposedReply) {
              appendChatMessage(proposedReply, 'outbound');
            }
          }
        }
        fetchLeads();
        fetchAuditLogs();
      }, 300);
    } catch (err) {
      console.error('Simulator webhook error', err);
    }
  });

  // Initial welcome message in simulator
  appendChatMessage('Hello Amitabh, thank you for your interest in Shree Heights, Chandannagar (RERA: WBRERA/P/HOO/2023/000504). We offer thoughtfully crafted 2 & 3 BHK homes starting from ₹70 lakhs onwards. Would you like to schedule a private site visit this week?', 'outbound');
}

function appendChatMessage(text, direction) {
  const stream = document.getElementById('sim-chat-stream');
  const msgEl = document.createElement('div');
  msgEl.className = `msg-bubble ${direction}`;
  const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  msgEl.innerHTML = `
    <div>${escapeHtml(text)}</div>
    <div class="msg-time">${time}</div>
  `;
  stream.appendChild(msgEl);
  stream.scrollTop = stream.scrollHeight;
}

function updateGrokInspector(lead, lastCustomerMsg) {
  const badge = document.getElementById('sim-intent-badge');
  badge.textContent = (lead.intent || 'WARM').toUpperCase();
  badge.className = `chat-status-badge badge-pill ${lead.intent || 'warm'}`;

  document.getElementById('grok-intent').textContent = (lead.intent || 'warm').toUpperCase();
  document.getElementById('grok-action').textContent = lead.next_action || 'ask_qualifying_question';

  // Fetch latest audit details
  fetch(`/api/audit?lead_id=${lead.lead_id}`).then(r => r.json()).then(data => {
    const entry = data.entries?.[0];
    if (entry && entry.details) {
      document.getElementById('grok-reason').textContent = entry.details.reason || entry.block_reason || 'Evidence derived from customer reply';
      document.getElementById('grok-preferences').textContent = JSON.stringify(entry.details.preferences || {}, null, 2);
      document.getElementById('grok-missing').textContent = entry.details.missing_information || 'None';
      document.getElementById('grok-reply').textContent = entry.details.proposed_reply || 'Follow-up reply prepared.';
      document.getElementById('grok-confidence').textContent = '92% (High Confidence)';
    }
  });
}

// -------------------------------------------------------------
// Policy Gate Inspector
// -------------------------------------------------------------
function initPolicyGateInspector() {
  const btn = document.getElementById('btn-run-gate-test');
  btn.addEventListener('click', runGateInspection);
}

async function runGateInspection() {
  const leadId = document.getElementById('gate-lead-select').value;
  const timeOption = document.getElementById('gate-time-select').value;
  const msgOption = document.getElementById('gate-msg-type').value;

  let simulatedNow;
  if (timeOption === 'daytime') {
    simulatedNow = new Date('2026-10-12T08:30:00Z'); // 14:00 IST
  } else if (timeOption === 'night') {
    simulatedNow = new Date('2026-10-12T18:00:00Z'); // 23:30 IST
  } else {
    simulatedNow = new Date('2026-10-12T00:30:00Z'); // 06:00 IST
  }

  let messagePayload;
  if (msgOption === 'approved_template') {
    messagePayload = {
      text: 'Hello, welcome to Shree Heights.',
      is_template: true,
      template_name: 'shree_heights_first_outreach'
    };
  } else if (msgOption === 'free_text') {
    messagePayload = {
      text: 'Hello there, please check this special deal.',
      is_template: false
    };
  } else {
    messagePayload = {
      text: 'Special Shree Heights unit offer for ₹85.5 lakhs today only!',
      is_template: true,
      template_name: 'shree_heights_first_outreach'
    };
  }

  try {
    const res = await fetch('/api/policy/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        lead_id: leadId,
        message: messagePayload,
        context: { now: simulatedNow }
      })
    });

    const result = await res.json();
    renderGateResults(result);
  } catch (err) {
    alert('Policy check failed: ' + err.message);
  }
}

function renderGateResults(result) {
  const verdictEl = document.getElementById('gate-overall-verdict');
  if (result.allowed) {
    verdictEl.className = 'overall-verdict allowed';
    verdictEl.innerHTML = `<span class="verdict-icon">✅</span><span>POLICY PASSED — Safe to send message</span>`;
  } else {
    verdictEl.className = 'overall-verdict blocked';
    verdictEl.innerHTML = `<span class="verdict-icon">🚫</span><span>BLOCKED: ${escapeHtml(result.reason_code)} — ${escapeHtml(result.reason_detail)}</span>`;
  }

  const checks = result.checks || {};
  setCheckState('chk-optout', checks.opt_out_cleared);
  setCheckState('chk-consent', checks.consent_valid);
  setCheckState('chk-frequency', checks.frequency_cleared);
  setCheckState('chk-window', checks.window_cleared);
  setCheckState('chk-template', checks.template_cleared);
  setCheckState('chk-facts', checks.facts_verified);
}

function setCheckState(id, passed) {
  const el = document.getElementById(id);
  if (!el) return;
  if (passed) {
    el.className = 'check-item passed';
    el.querySelector('.check-icon').textContent = '✅';
  } else {
    el.className = 'check-item failed';
    el.querySelector('.check-icon').textContent = '❌';
  }
}

// -------------------------------------------------------------
// Audit Logs
// -------------------------------------------------------------
async function fetchAuditLogs() {
  try {
    const policyFilter = document.getElementById('filter-audit-policy').value;
    const url = policyFilter ? `/api/audit?policy_result=${encodeURIComponent(policyFilter)}` : '/api/audit';
    const res = await fetch(url);
    const data = await res.json();
    const entries = data.entries || [];

    const tbody = document.getElementById('audit-table-body');
    tbody.innerHTML = '';

    if (entries.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" class="loading-td">No audit records found.</td></tr>';
      return;
    }

    entries.forEach(entry => {
      const tr = document.createElement('tr');
      const timeStr = entry.timestamp ? new Date(entry.timestamp).toLocaleTimeString() : '-';

      const outcomeBadge = entry.policy_result === 'ALLOWED'
        ? '<span class="badge-pill yes">ALLOWED</span>'
        : (entry.policy_result === 'BLOCKED' ? '<span class="badge-pill no">BLOCKED</span>' : '<span class="badge-pill cold">INFO</span>');

      tr.innerHTML = `
        <td style="font-family:var(--font-mono); font-size:0.75rem;">${timeStr}</td>
        <td><code>${escapeHtml(entry.lead_id || '-')}</code></td>
        <td><strong>${escapeHtml(entry.event_type || '-')}</strong></td>
        <td>${outcomeBadge}</td>
        <td style="font-size:0.78rem; max-width:240px;">${escapeHtml(entry.block_reason || entry.details?.reason || 'Verified check passed')}</td>
        <td>${entry.interpreted_intent ? `<span class="badge-pill ${entry.interpreted_intent}">${entry.interpreted_intent.toUpperCase()}</span>` : '-'}</td>
        <td><code style="font-size:0.75rem; color:#fde047;">${escapeHtml(entry.recommended_action || '-')}</code></td>
        <td><span style="font-size:0.75rem;">${escapeHtml(entry.approval_status || '-')}</span></td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    console.error('Failed to load audit logs', err);
  }
}

document.getElementById('filter-audit-policy').addEventListener('change', fetchAuditLogs);
document.getElementById('btn-refresh-audit').addEventListener('click', fetchAuditLogs);

// Utility
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
